Supplementary material for:

Ali Baharev, Arnold Neumaier; A globally convergent method to find all
steady-state solutions of distillation columns; AIChE Journal, 2013

- examples folder: illustrative examples are elaborated to show how 
  the proposed method works

- model folder: the detailed steady-state model of the reactive 
  distillation column considered in the paper

- sources: the C++ source code of the proof-of-concept implementation,
  (at revision 1396).
  
- all_in_one.zip: everything as a single zip file.  

The research was funded by the Austrian Science Fund (FWF): P23554.
Project title: Structure driven methods for large-scale optimization

