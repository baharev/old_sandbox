
The vector-based image of the sparsity pattern, which can be scaled by 
any amount without degrading quality, is given in RD_sparsity.pdf. The
recommended PDF viewer is the Adobe Reader (free).

The elimination order is fully detailed in RD_elimination.pdf.

Since AMPL is a de facto standard in the optimization community, the
model is given as an AMPL model in RD_AMPL.txt. The symbolic names of
the rows and the columns are also visible in the sparsity pattern
picture (RD_sparsity.pdf) but the symbols "_", "[" and "]" had to be 
removed from the names. The row and column permutations are given in the
RD_column_permutation.txt and RD_row_permutation.txt files to help
reproducibility.
