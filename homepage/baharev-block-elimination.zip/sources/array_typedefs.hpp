//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#ifndef ARRAY_TYPEDEFS_HPP_
#define ARRAY_TYPEDEFS_HPP_

#include <vector>

typedef std::vector<double>  rvector;
typedef std::vector<rvector> rmatrix;

typedef std::vector<int>  ivector;
typedef std::vector<ivector> imatrix;

struct vec2 {
	vec2(double x, double y) : x(x), y(y) { }
	double x;
	double y;
};

typedef std::vector<vec2> vector_vec2;

typedef std::vector<vector_vec2> matrix_vec2;

#endif

