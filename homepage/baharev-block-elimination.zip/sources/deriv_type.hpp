//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#ifndef DERIV_TYPE_HPP_
#define DERIV_TYPE_HPP_

#include <cmath>

class deriv_type {

public:

	deriv_type() : f(0.0), df(0.0) { }

	deriv_type(double x, double derivative = 0.0)
	: f(x), df(derivative) { }

	double f_value() const { return f; }

	double derivative() const { return df; }

	friend const deriv_type operator+(const deriv_type& x, const deriv_type& y) {

		return deriv_type(x.f+y.f, x.df+y.df);
	}

	deriv_type& operator+=(const deriv_type& x) { f += x.f; df += x.df; return *this; }

	deriv_type& operator-=(const deriv_type& x) { f -= x.f; df -= x.df; return *this; }

	friend const deriv_type operator-(const deriv_type& x) {

		return deriv_type(-x.f, -x.df);
	}

	friend const deriv_type operator-(const deriv_type& x, const deriv_type& y) {

		return deriv_type(x.f-y.f, x.df-y.df);
	}

	friend const deriv_type operator*(const deriv_type& x, const deriv_type& y) {

		return deriv_type(x.f*y.f, x.df*y.f+x.f*y.df);
	}

	friend const deriv_type operator/(const deriv_type& x, const deriv_type& y) {

		double zf  = x.f/y.f;

		double zdf = (x.df - zf*y.df)/y.f;

		return deriv_type(zf, zdf);
	}

	friend const deriv_type exp(const deriv_type& x) {

		double zf  = std::exp(x.f);

		double zdf = x.df*zf;

		return deriv_type(zf, zdf);
	}

	friend const deriv_type log(const deriv_type& x) {

		return deriv_type(std::log(x.f), x.df/x.f);
	}

private:

	double f;
	double df;
};

#endif

