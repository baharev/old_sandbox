//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#include "front.hpp"

const vector_vec2 front::transform_output_to_2D(const rmatrix& y) const {

	vector_vec2 points;

	const int n = y.size();

	for (int i=0; i<n; ++i) {

		points.push_back(output_to_plot(y.at(i)));
	}

	return points;
}

// TODO Duplication!
const vector_vec2 front::transform_input_to_2D(const rmatrix& y) const {

	vector_vec2 points;

	const int n = y.size();

	for (int i=0; i<n; ++i) {

		points.push_back(input_to_plot(y.at(i)));
	}

	return points;
}

bool front::is_edge_only_partly_feasible(const rvector& x, const rvector& y) const {

	bool x_infeas = is_infeasible(x);

	bool y_infeas = is_infeasible(y);

	return (x_infeas && !y_infeas) || (!x_infeas && y_infeas);
}
