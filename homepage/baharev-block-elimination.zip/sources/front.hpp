//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#ifndef FRONT_HPP_
#define FRONT_HPP_

#include "array_typedefs.hpp"

class front {

public:

	virtual const rvector forward_propagate(const rvector& x) = 0;

	virtual const rvector internal_vars() const { return rvector(); } // TODO Is it really the best

	virtual bool is_infeasible(const rvector& y) const = 0;

	virtual bool is_edge_only_partly_feasible(const rvector& x, const rvector& y) const;

	virtual int extend_to_the_boundary(rmatrix& samples) const { return 0; }

	virtual void fix_partial_infeasibility(rvector& x, rvector& y) const { }

	virtual const rvector project(const rvector& y) const = 0;

	const vector_vec2 transform_output_to_2D(const rmatrix& y) const;

	const vector_vec2 transform_input_to_2D(const rmatrix& y) const;

	virtual ~front() { }

protected:

	virtual const vec2 output_to_plot(const rvector& y) const = 0;

	virtual const vec2 input_to_plot(const rvector& y) const { return output_to_plot(y); }

};

#endif
