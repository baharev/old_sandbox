//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#include <cassert>
#include "initial_points.hpp"

initial_points::initial_points(const rvector& start, const rvector& end, int n)
: k(0), start(start), end(end), n(n)
{
	assert(start.size()==end.size());

	assert(n>0);
}

const rvector initial_points::next() {

	const int dim = start.size();

	rvector res(dim);

	for (int i=0; i<dim; ++i) {

		res.at(i) = ((n-k)*start.at(i) + k*end.at(i)) / n;
	}

	++k;

	return res;
}
