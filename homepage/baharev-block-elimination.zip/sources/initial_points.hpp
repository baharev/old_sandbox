//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#ifndef INITIAL_POINTS_HPP_
#define INITIAL_POINTS_HPP_

#include "array_typedefs.hpp"

class initial_points {

public:

	initial_points(const rvector& start, const rvector& end, int n);

	bool has_next() const { return k <= n; }

	int index() const { return k-1; }

	const rvector next();

private:

	int k;

	const rvector start;

	const rvector end;

	const int n;

};

#endif

