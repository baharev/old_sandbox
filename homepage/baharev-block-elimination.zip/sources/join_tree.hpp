//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#ifndef JOIN_TREE_HPP_
#define JOIN_TREE_HPP_

#include "array_typedefs.hpp"

class front;

class join_tree {

public:

	virtual int size() const = 0;

	virtual front& get_front(int i) = 0; // TODO Use iterators instead

	virtual ~join_tree() { }

};

#endif
