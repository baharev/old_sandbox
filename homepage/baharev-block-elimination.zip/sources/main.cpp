//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#include <iostream>
#include <iomanip>
#include <fstream>
#include <memory>
#include <sstream>
#include "front.hpp"
#include "propagator.hpp"
#include "search_coordinator.hpp"
#include "vector_graphics.hpp"
#include "reactor_column.hpp"
#include "rd_R1_eg.hpp"

using namespace std;

void reactor_column_test() {

	const auto_ptr<join_tree> fronts( new reactor_column() );

	propagator propagator(fronts.get());

	rvector TR_1(1, 144.7974087707405);

	propagator.test_single_input(TR_1);

	rvector TR_2(1, 140.70909728056418);

	propagator.test_single_input(TR_2);

	rvector begin(1, 140.0);

	rvector end(1, 150.0);

	propagator.populate_initial_front_input(begin, end, 10);

	search_coordinator search(propagator);

	search.run();
}

struct fig_point {
	fig_point(double lambda, const vector<rmatrix>& solutions)
	: lambda(lambda), solutions(solutions) { }
	double lambda;
	vector<rmatrix> solutions;
};

vector<fig_point> solutions;

const string int2str(int i) {
	ostringstream os;
	os << i;
	return os.str();
}

void reactive_distillation_test(int i, double lambda) {

	set_lambda(lambda);

	const auto_ptr<join_tree> fronts( new reactive_distillation() );

	propagator propagator(fronts.get());

	rvector begin(1, -1.0e-12);

	rvector end(1, eta_max()+1.0e-12);

	propagator.populate_initial_front_input(begin, end, 20000);

	search_coordinator search(propagator);

	search.run();

	solutions.push_back(fig_point(lambda, search.get_solutions()));

}

void bifurcation_diagram(int FRONT_TO_PLOT) {

	string filename("bifurk_"+int2str(FRONT_TO_PLOT)+".dat");

	ofstream out(filename.c_str());

	for (int i=0; i<solutions.size(); ++i) {

		const fig_point& data = solutions.at(i);

		out << data.lambda << '\t';

		const vector<rmatrix>& sols = data.solutions;

		for (int j=0; j<sols.size(); ++j) {

			const rvector& sol = sols.at(j).at(FRONT_TO_PLOT);

			for (int m=0; m<sol.size(); ++m) {

				out <<  sol.at(m) << '\t';
			}

			out << '\t';
		}

		out << '\n';
	}
}

void lambda_x_diagram(const char* fname, int component, int FRONT_TO_PLOT) {

	string filename(fname+int2str(FRONT_TO_PLOT));

	ofstream out(filename.c_str());

	for (int i=0; i<solutions.size(); ++i) {

		const fig_point& data = solutions.at(i);

		out << setprecision(8) << scientific;

		out << data.lambda << '\t';

		const vector<rmatrix>& sols = data.solutions;

		for (int j=0; j<sols.size(); ++j) {

			const rvector& sol = sols.at(j).at(FRONT_TO_PLOT);

			double L = 0.0;

			for (int m=0; m<3; ++m) {

				L += sol.at(m);
			}

			out << sol.at(component)/L << '\t';
		}

		out << '\n';
	}
}

void save_profiles_at_lambda(double lambda, const matrix_vec2& T_profiles) {

	static int counter = 0;

	ostringstream os;

	os << "temp_" << counter++ << ".asy";

	vector_graphics graph(os.str().c_str());

	os.str("");

	os << "// lambda " << lambda;

	graph.write_line(os.str().c_str());

	graph.write("temp_prof", T_profiles);
}

void temp_profile() {

	const auto_ptr<join_tree> fronts( new reactive_distillation() );

	for (int i=0; i<solutions.size(); ++i) {

		const fig_point& data = solutions.at(i);

		const vector<rmatrix>& sols = data.solutions;

		matrix_vec2 T_profiles;

		for (int j=0; j<sols.size(); ++j) {

			const rmatrix& sol = sols.at(j);

			vector_vec2 profile;

			for (int k=10; k>=1; --k) {

				front& stage = fronts->get_front(k);

				stage.forward_propagate(sol.at(k));

				double T = stage.internal_vars().at(0);

				profile.push_back(vec2(T, k));
			}

			T_profiles.push_back(profile);
		}

		save_profiles_at_lambda(data.lambda, T_profiles);
	}
}

int main() {

	reactor_column_test();

	double lambdas[] = { 10.0 };

	const int n = sizeof lambdas / sizeof lambdas[0];

	for (int i=0; i<n; ++i) {

		reactive_distillation_test(i, lambdas[i]);
		cout << "lambda: " << lambdas[i] << endl;
	}

	int FRONT_TO_PLOT = 6;

	enum { ETHYLENE_OXIDE, WATER, ETHYLENE_GLYCOL };

	bifurcation_diagram(FRONT_TO_PLOT);

	lambda_x_diagram("lam_x3_", ETHYLENE_GLYCOL, FRONT_TO_PLOT);

	temp_profile();

	return 0;
}

