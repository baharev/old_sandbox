//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#include "plotter.hpp"
#include "vector_graphics.hpp"

using namespace std;

void plotter::dump(const char* file_name, const matrix_vec2& in, const matrix_vec2& out){

	vector_graphics asy(file_name);

	asy.write("in",  in);
	asy.write("out", out);

}
