//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#ifndef PLOTTER_HPP_
#define PLOTTER_HPP_

#include "array_typedefs.hpp"

class plotter {

public:

	void dump(const char* file_name, const matrix_vec2& in, const matrix_vec2& out);

private:

};

#endif

