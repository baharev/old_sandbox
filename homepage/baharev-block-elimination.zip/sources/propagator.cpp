//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#include <algorithm>
#include <cmath>
#include <iostream>
#include <iomanip>
#include <iterator>
#include <cassert>
#include <limits>
#include "propagator.hpp"
#include "join_tree.hpp"
#include "front.hpp"
#include "initial_points.hpp"
#include "plotter.hpp"

using namespace std;

propagator::propagator(join_tree* fronts) : fronts(fronts), number_of_fronts(fronts->size()), current_front_index(-1) {

}

void propagator::populate_initial_front_input(const rvector& begin, const rvector& end, int number_of_intervals) {

	assert(begin.size() == end.size());

	clear_all();

	initial_points generator(begin, end, number_of_intervals);

	while (generator.has_next()) {

		in.at(0).push_back( generator.next() );
	}

	init_sample_counters();
}

void propagator::test_single_input(const rvector& initial_point) {

	clear_all();

	in.at(0).push_back( initial_point );

	init_sample_counters();

	forward_sweep();

	show_residuals();
}

void propagator::clear_all() {

	in.clear();
	out.clear();
	internals.clear();
	solutions.clear();
	index_map.clear();
	current_front_index = -1;

	in.resize(number_of_fronts);
	out.resize(number_of_fronts);
	internals.resize(number_of_fronts);
	index_map.resize(number_of_fronts);
}

void propagator::init_sample_counters() {

	sample_size_counters.begin = in.at(0).size();

	sample_size_counters.min = sample_size_counters.max = sample_size_counters.begin;

	sample_size_counters.end = 0;
}

void propagator::update_sample_counters(int num_of_samples) {

	sample_size_counters.end = num_of_samples;

	if (num_of_samples > sample_size_counters.max) {

		sample_size_counters.max = num_of_samples;
	}
	else if (num_of_samples < sample_size_counters.min) {

		sample_size_counters.min = num_of_samples;
	}
}

void propagator::show_counters() const {

	cout << "===============================================================\n";
	cout << "number of samples begin/end/min/max:\t";
	cout << sample_size_counters.begin << '\t' << sample_size_counters.end << '\t';
	cout << sample_size_counters.min   << '\t' << sample_size_counters.max << '\n';
}

bool propagator::has_next_front() const {

	return current_front_index < number_of_fronts - 1;
}

bool propagator::is_last_front() const {

	return current_front_index == number_of_fronts - 1;
}

void propagator::set_next_front() {

	assert(has_next_front());

	++current_front_index;

	cout << "-------------------------------------------------------------" << endl;
	cout << "started at front " << current_front_index ;
	cout << " with " << current_samples().size() << " samples" << endl;
}

void propagator::forward_sweep() {

	cout << setprecision(3) << scientific;

	for (int i=0; has_next_front(); ++i) {

		set_next_front();

		process_each_sample_at_front();

		copy_output_to_input_of_next();

		discontinuities();

		prepapare_input_of_next();
	}

	dump_results();
}

int propagator::discontinuities() const {

	if (is_last_front() || input_for_next_front().size()<2) {

		return 0;
	}

	const rmatrix& samples = input_for_next_front();

	int part = -1;

	const int n_edges = samples.size() - 2;

	bool on_manifold = false;

	for (int k=0; k<n_edges; ++k) {

		if (!on_manifold && (is_edge_feasible(k) || is_edge_only_partly_feasible(k))) {

			on_manifold = true;

			++part;
		}

		if (on_manifold && is_edge_fully_infeasible(k)) {

			on_manifold = false;
		}
	}

	if (part == -1) {

		for (int i=0; i<samples.size(); ++i) {

			assert(current_front().is_infeasible(samples.at(i)));
		}
	}

	//cout << "disconnected: " << discon << endl;

	return part;
}

void propagator::keep_only_part(int part) {

	rmatrix& samples = input_for_next_front();

	ivector& indices = front_index_map();

	if (samples.size()<2) {

		return;
	}

	int left(0); int rigth(samples.size()-1);

	int feas_part = -1;

	const int n_edges = samples.size() - 2;

	bool on_manifold = false;

	for (int k=0; k<n_edges; ++k) {

		if (!on_manifold && (is_edge_feasible(k) || is_edge_only_partly_feasible(k))) {

			on_manifold = true;

			++feas_part;

			left = k;
		}

		if (on_manifold && is_edge_fully_infeasible(k)) {

			on_manifold = false;

			rigth = k;

			if (feas_part == part) {

				break;
			}
		}
	}

	assert(feas_part==part);

	if (left > rigth && on_manifold) { // HACK Should be set by the loop
	
		rigth = samples.size()-1;
	}

	assert(left < rigth);

	const rmatrix::const_iterator samp_beg(samples.begin());

	rmatrix new_samples = rmatrix(samp_beg + left, samp_beg + (rigth+1));

	const ivector::const_iterator ind_beg(indices.begin());

	ivector new_indices = ivector(ind_beg + left, ind_beg + (rigth+1));

	samples.assign(new_samples.begin(), new_samples.end());

	indices.assign(new_indices.begin(), new_indices.end());
}

void propagator::process_each_sample_at_front() {

	const int n_samples = current_samples().size();

	update_sample_counters(n_samples);

	for (int k=0; k<n_samples; ++k) {

		const rvector& x = current_samples().at(k);

		out.at(current_front_index).push_back( current_front().forward_propagate(x) );

		internals.at(current_front_index).push_back( current_front().internal_vars() );
	}
}

void propagator::prepapare_input_of_next() {

	if (is_last_front()) {

		return;
	}

	const int infeas = remove_infeasible();

	cout << "infeasible:   " << infeas << " samples" << endl;

	//assert(remove_infeasible()==0); // FIXME Should be able to check invariants

	//const int extrapol = extend_to_the_boundary();

	//cout << "extrapolated: " << extrapol << " samples" << endl;

	const int removed = remove_close_points();

	cout << "removed:      " << removed << " samples" << endl;

	//assert(remove_close_points()==0); // FIXME How on Earth is it???

	const int inserted = insert_new_points();

	cout << "inserted:     " << inserted << " samples" << endl;

	//assert(insert_new_points()==0); // FIXME How on Earth is it???
}

void propagator::copy_output_to_input_of_next() {

	if (is_last_front()) {

		return;
	}

	int i = current_front_index;

	const int n = out.at(i).size();

	ivector& indices = index_map.at(i);

	indices.resize(n);

	for (int k=0; k<n; ++k) {

		indices.at(k) = k;
	}

	const rmatrix& prev = out.at(i);

	++i;

	in.at(i).assign(prev.begin(), prev.end());
}

void propagator::show_residuals() const {

	const int last = number_of_fronts-1;

	const int m = out.at(last).size();

	for (int k=0; k<m; ++k) {

		cout << k << ":  ";

		const rvector& v = out.at(last).at(k);

		copy(v.begin(), v.end(), ostream_iterator<double>(cout, "\t"));

		cout << endl;
	}
}

bool sign_changed(const rvector& u, const rvector& v) {

	assert(u.size()==v.size());

	const size_t n = u.size();

	for (size_t i=0; i<n; ++i) {

		if (u.at(i)*v.at(i)>=0) {

			return false;
		}
	}

	return true;
}

void print(const rvector& v) {

	copy(v.begin(), v.end(), ostream_iterator<double>(cout, "\t"));
}

int propagator::dump_results() const {

	show_counters();

	int solutions = sign_changes().size();

	cout << "Sign changes: " << solutions << endl;

	return solutions;

/*
	const rmatrix& last_front_samples = out.back();

	const int n_samples = last_front_samples.size();

	const int dim_out_last = last_front_samples.front().size();

	rvector u(dim_out_last, 0.0);

	for (int k=0; k<n_samples; ++k) {

		cout << fixed << setprecision(3);

		const rvector& v = last_front_samples.at(k);

		print(v);

		cout << (sign_changed(u,v)?'*':' ') << endl; // sign change does not generalize well

		u = v;
	}
*/
}

const rvector substract(const rvector& x, const rvector& y) {

	assert(x.size()==y.size());

	const size_t n = x.size();

	rvector z(n, 0.0);

	for (size_t i=0; i<n; ++i) {

		z.at(i) = x.at(i)-y.at(i);
	}

	return z;
}

double dot_prod(const rvector& x, const rvector& y) {

	assert(x.size()==y.size());

	const size_t n = x.size();

	double prod = 0.0;

	for (size_t i=0; i<n; ++i) {

		prod += x.at(i)*y.at(i);
	}

	return prod;
}

double length(const rvector& x) {

	return std::sqrt( dot_prod(x,x) );
}

const rvector lin_interpol(const rvector& x, const rvector& y, double lambda) {

	assert(x.size()==y.size());

	const int size = x.size();

	rvector res(size, 0.0);

	for (int k=0; k<size; ++k) {

		res.at(k) = lambda*x.at(k) + (1-lambda)*y.at(k);
	}

	return res;
}

bool is_between(double x, double y, double c) {

	return (x<=c && c<=y) || (x>=c && c>=y);
}

bool is_between(const rvector& x, const rvector& y, const rvector& c) {

	assert(x.size()==y.size());
	assert(x.size()==c.size());

	const size_t n = x.size();

	for (size_t i=0; i<n; ++i) {

		if (!is_between(x.at(i), y.at(i), c.at(i))) {

			return false;
		}
	}

	return true;
}

double difference_sqr(const rvector& x, const rvector& y) {

	assert(x.size()==y.size());

	const size_t n = x.size();

	double z = 0;

	for (size_t i=0; i<n; ++i) {

		double diff = x.at(i)-y.at(i);

		z += diff*diff;
	}

	return z;
}

const rvector propagator::solution_component(int front_i, const lin_ipol& image) const {

	const rmatrix& input = in.at(front_i);

	return lin_interpol(input.at(image.left), input.at(image.left+1), image.lambda);
}

const vector<rmatrix>& propagator::backward_sweep_new() {

	const vector<lin_ipol> sols = sign_changes();

	solutions.clear();

	solutions.resize(sols.size());

	cout << "Sign changes: " << sols.size() << endl;

	const int last = number_of_fronts - 1;

	for (size_t s=0; s<sols.size(); ++s) {

		lin_ipol image = sols.at(s);

		solutions.at(s).resize(number_of_fronts);

		rmatrix& solution = solutions.at(s);

		solution.at(last) = solution_component(last, image);

		print(solution.at(last)); cout << endl;

		for (int i=number_of_fronts-2; i>=0; --i) {

			image = backward_step(i, image);

			solution.at(i) = solution_component(i, image);

			print(solution.at(i)); cout << endl;
		}

		cout << endl;
	}

	return solutions;
}

const vector<propagator::lin_ipol> propagator::sign_changes() const {

	const int dim_of_last_front_out = out.back().front().size(); // TODO Unreadable

	const rvector c = rvector(dim_of_last_front_out, 0);

	const rmatrix& outs = out.at(number_of_fronts-1);

	vector<lin_ipol> index_of_sign_change;

	for (size_t k=0; k<outs.size()-1; ++k) {

		const rvector& x = outs.at(k  );

		const rvector& y = outs.at(k+1);

		double lam = lambda(x, y, c);

		if (is_between(x,y,c) && (0<=lam && lam<=1)) {

			index_of_sign_change.push_back(lin_ipol(k, lam));
		}
	}

	return index_of_sign_change;
}

const propagator::lin_ipol propagator::backward_step(int front_i, const lin_ipol& point) const {

	const index_pair range = find_enclosing_indices(front_i, point.left);

	const rvector c = lin_interpol(in.at(front_i+1).at(point.left), in.at(front_i+1).at(point.left+1), point.lambda);

	const rmatrix& outs = out.at(front_i);

	double distance = numeric_limits<double>::max();

	lin_ipol image(-1, -1);

	for (int k=range.left; k<range.rigth; ++k) {

		const rvector& x = outs.at(k  );

		const rvector& y = outs.at(k+1);

		double lam = lambda(x, y, c);

		const rvector estimate = lin_interpol(x, y, lam);

		double dist_estim = difference_sqr(estimate, c);

		if (dist_estim < distance) {

			distance = dist_estim;

			image = lin_ipol(k, lam);
		}
	}

	assert(image.left >= 0);

	return image;
}

const propagator::index_pair propagator::find_enclosing_indices(int front_i, int index_in_input) const {

	const ivector& indices = get_index_map(front_i);

	assert(in.at(front_i+1).size()==indices.size());

	int left = -1;

	for (int i=index_in_input; i>=0; --i) {

		if (indices.at(i)>=0) {

			left = indices.at(i);

			break;
		}
	}

	assert(left>=0);

	int right = -1;

	for (size_t i=index_in_input+1; i<indices.size(); ++i) {

		if (indices.at(i)>=0) {

			right = indices.at(i);

			break;
		}
	}

	assert(left<right);

	return index_pair(left, right);
}

double propagator::lambda(const rvector& x, const rvector& y, const rvector& c) const {

		const rvector x_y = substract(x, y);

		const rvector c_y = substract(c, y);

		return dot_prod(x_y, c_y) / dot_prod(x_y, x_y);
}

void propagator::dump_dataset_to_plot(const char* file_name) const {

	matrix_vec2 in_points, out_points;

	for (int i=0; i<=current_front_index; ++i) {

		const front& f = fronts->get_front(i);

		in_points.push_back( f.transform_input_to_2D( in.at(i)) );

		out_points.push_back(f.transform_output_to_2D(out.at(i)) );
	}

	plotter plot;

	plot.dump(file_name, in_points, out_points);
}

int propagator::remove_infeasible() {

	int infeas = remove_strict_infeasiblity();

	fix_partial_infeasibility();

	return infeas;
}

int propagator::remove_strict_infeasiblity() {

	if (input_for_next_front().size() < 2) {

		return 0;
	}

	rmatrix& samples = input_for_next_front();

	ivector& indices = front_index_map();

	int infeas = 0;

	infeas += remove_strict_infeas_front(samples, indices);

	infeas += remove_strict_infeas_back(samples, indices);

	assert(samples.size() == indices.size()); // TODO Clearly, samples and indices should be wrapped up...

	return infeas;
}

template <class Cont>
void erase_front(Cont& cont) {

	assert(!cont.empty());

	cont.erase(cont.begin());
}

template <class Cont>
void erase_back(Cont& cont) {

	assert(!cont.empty());

	cont.pop_back();
}

int propagator::remove_strict_infeas_front(rmatrix& samples, ivector& indices) {

	int infeas = 0;

	while (is_edge_fully_infeasible(0)) {

		erase_front(samples);

		erase_front(indices);

		++infeas;
	}

	return infeas;
}

int propagator::remove_strict_infeas_back(rmatrix& samples, ivector& indices) {

	int infeas = 0;

	int last_edge_left_endpoint = samples.size() - 2;

	while (is_edge_fully_infeasible(last_edge_left_endpoint)) {

		erase_back(samples);

		erase_back(indices);

		++infeas;

		last_edge_left_endpoint = samples.size() - 2;
	}

	return infeas;
}

void propagator::fix_partial_infeasibility() {

	if (input_for_next_front().size()<2) {

		return;
	}

	rmatrix& samples = input_for_next_front();

	if (samples.size()==2 && is_edge_only_partly_feasible(0)) {

		current_front().fix_partial_infeasibility(samples.at(0), samples.at(1));

		return;
	}

	if (is_edge_only_partly_feasible(0)) {

		current_front().fix_partial_infeasibility(samples.at(1), samples.at(0));

		//front_index_map().at(0) = -1;
	}

	int rigth = samples.size() - 1;

	int left  = rigth - 1;

	if (is_edge_only_partly_feasible(left)) {

		current_front().fix_partial_infeasibility(samples.at(left), samples.at(rigth));

		//front_index_map().at(last) = -1;
	}
}

template <class Cont>
void erase_pos(Cont& cont, int pos) {

	assert(cont.begin()+pos < cont.end());

	cont.erase(cont.begin()+pos);
}

int propagator::remove_close_points() {

	if (input_for_next_front().size() < 2) {

		return 0;
	}

	compute_delta();

	compute_scales();

	rmatrix& samples = input_for_next_front();

	ivector& indices = front_index_map();

	//dump_sample_measures(samples);

	int removed = 0;

	for (size_t k=1; k<samples.size()-1; ++k) {

		if (is_too_close(samples, k)) {

			erase_pos(samples, k);

			erase_pos(indices, k);

			k = (k>1) ? k-2 : k-1; // the previous triplet, if exists, has not been examined

			++removed;
		}
	}

	//dump_sample_measures(samples);

	assert(samples.size() == indices.size());

	return removed;
}

void propagator::dump_sample_measures(const rmatrix& samples) const {

	cout << "delta: " << sqrt(get_delta()) << endl;

	for (size_t k=1; k<samples.size()-1; ++k) {

		cout << k;

		double cos_phi = cos_angle(samples, k);

		double dm = distance_sqr(samples.at(k-1), samples.at(k));

		double dp = distance_sqr(samples.at(k), samples.at(k+1));

		cout << "\td-\t" << sqrt(dm) << "\td+\t" << sqrt(dp) << "\tphi\t";

		cout << fixed << setprecision(1) << acos(cos_phi)*(180.0/M_PI) << (is_too_close(samples, k)?"\t*":"") << endl;

		cout << scientific << setprecision(3);
	}
}

int propagator::insert_new_points() {

	int inserted = 0;

	rmatrix& samples = input_for_next_front();

	for (size_t k=1; k<samples.size(); ++k) {

		int new_points = insert_with_lin_interpol(samples, k);

		k += new_points;

		inserted += new_points;
	}

	return inserted;
}

int propagator::points_to_be_inserted(const rmatrix& samples, int k) const {

	double dist_sqr = distance_sqr(samples.at(k-1), samples.at(k));

	int points = std::floor(std::sqrt(dist_sqr/get_delta())) - 1;

	return  std::max(points, 0); // HACK Is the -1 correct above?
}

int propagator::insert_with_lin_interpol(rmatrix& samples, int k) {

	const int points_to_insert = points_to_be_inserted(samples, k);

	if (points_to_insert == 0) {

		return 0;
	}

	const rvector& first = samples.at(k-1);

	const rvector& last  = samples.at(k);

	rmatrix new_points;

	new_points.reserve(points_to_insert);

	const int n = points_to_insert + 1;

	for (int i=1; i<=points_to_insert; ++i) {

		new_points.push_back( lin_interpol(first, last, static_cast<double>(n-i)/n) );
	}

	assert(new_points.size()==static_cast<size_t>(points_to_insert));

	samples.insert(samples.begin()+k, new_points.begin(), new_points.end());

	ivector& indices = front_index_map();

	indices.insert(indices.begin()+k, points_to_insert, -1);

	assert(samples.size() == indices.size());

	return points_to_insert;
}

bool propagator::is_too_close(const rmatrix& samples, int k) const {

	//double d = distance_sqr(samples.at(k-1), samples.at(k+1));

	double cos_phi = cos_angle(samples, k);

	double dm = distance_sqr(samples.at(k-1), samples.at(k));

	double dp = distance_sqr(samples.at(k), samples.at(k+1));

	double delta = get_delta();

	bool too_close = (cos_phi > 0.95) && (dm < delta) && (dp < delta);

	return too_close;
}

const rvector propagator::scaled_difference(const rvector& x, const rvector& y) const {

	assert(x.size()==y.size());

	assert(x.size()==scales.size());

	const size_t n = x.size();

	rvector z(n, 0.0);

	for (size_t i=0; i<n; ++i) {

		z.at(i) = (x.at(i)-y.at(i))/scales.at(i);
	}

	return z;
}

double propagator::cos_angle(const rmatrix& samples, int k) const {

	const rvector a = scaled_difference(samples.at(k  ), samples.at(k-1));

	const rvector b = scaled_difference(samples.at(k+1), samples.at(k  ));

	const double a_len = length(a);

	const double b_len = length(b);

	return dot_prod(a, b)/(a_len*b_len);
}

void propagator::compute_delta() {

	double threshold = manifold_length() / (sample_size_counters.begin-1);

	delta = threshold * threshold ;
}

double propagator::manifold_length() const {

	double length = 0.0;

	const rmatrix& samples = input_for_next_front();

	const int n = samples.size()-1;

	for (int i=0; i<n; ++i) {

		length += std::sqrt(distance_sqr(samples.at(i), samples.at(i+1)));
	}

	return length;
}

void abs_max(const rvector& x, const rvector& y, rvector& max) {

	assert(x.size()==y.size());

	const size_t n = x.size();

	for (size_t i=0; i<n; ++i) {

		double diff = std::fabs(x.at(i)-y.at(i));

		if (diff > max.at(i)) {

			max.at(i) = diff;
		}
	}
}

void propagator::compute_scales() {

	scales.clear();

	const rmatrix& samples = input_for_next_front();

	const int n   = samples.size()-1;

	const int dim = samples.at(0).size();

	scales.resize(dim, 0.0);

	for (int i=0; i<n; ++i) {

		abs_max(samples.at(i), samples.at(i+1), scales);
	}
}

double propagator::distance_sqr(const rvector& x, const rvector& y) const {

	const rvector x_img = current_front().project(x);

	const rvector y_img = current_front().project(y);

	const rvector dist  = substract(x_img, y_img);

	return dot_prod(dist, dist);
}

front& propagator::current_front() {

	return fronts->get_front(current_front_index);
}

const front& propagator::current_front() const {

	return fronts->get_front(current_front_index);
}

bool propagator::is_edge_fully_infeasible(int left_endpoint) const {

	return !is_edge_feasible(left_endpoint) && !is_edge_only_partly_feasible(left_endpoint);
}

bool propagator::is_edge_only_partly_feasible(int left_endpoint) const {

	const rmatrix& samples = input_for_next_front();

	const rvector& left  = samples.at(left_endpoint    );

	const rvector& rigth = samples.at(left_endpoint + 1);

	return current_front().is_edge_only_partly_feasible(left, rigth);
}

bool propagator::is_edge_feasible(int left_endpoint) const {

	const rmatrix& samples = input_for_next_front();

	const front& f = current_front();

	int rigth_endpoint = left_endpoint + 1;

	bool left  = !f.is_infeasible(samples.at( left_endpoint));

	bool rigth = !f.is_infeasible(samples.at(rigth_endpoint));

	return left && rigth;
}

rmatrix& propagator::current_samples() {

	return in.at(current_front_index);
}

const rmatrix& propagator::current_samples() const {

	return in.at(current_front_index);
}

rmatrix& propagator::input_for_next_front() {

	return in.at(current_front_index+1);
}

const rmatrix& propagator::input_for_next_front() const {

	return in.at(current_front_index+1);
}

ivector& propagator::front_index_map() {

	return index_map.at(current_front_index); // TODO Ugly, must be in sync with input_for_next_front
}

const ivector& propagator::get_index_map(int front_i) const {

	return index_map.at(front_i);
}

double propagator::get_delta() const {

	return delta;
}

