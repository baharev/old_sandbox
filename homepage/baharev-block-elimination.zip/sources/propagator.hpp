//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#ifndef PROPAGATOR_HPP_
#define PROPAGATOR_HPP_

#include "array_typedefs.hpp"

class join_tree;
class front;

class propagator {

public:

	propagator(join_tree* fronts);

	void populate_initial_front_input(const rvector& begin, const rvector& end, int number_of_intervals);

	void test_single_input(const rvector& initial_point);

	void forward_sweep();

	bool has_next_front() const;

	bool is_last_front() const;

	void set_next_front();

	void process_each_sample_at_front();

	void copy_output_to_input_of_next();

	int discontinuities() const;

	void prepapare_input_of_next();

	void keep_only_part(int part);

	const std::vector<rmatrix>& backward_sweep_new();

	void dump_dataset_to_plot(const char* file_name) const;

	int dump_results() const;

private:

	struct lin_ipol {
		lin_ipol(int left, double lambda) : left(left), lambda(lambda) { }
		int left;
		double lambda;
	};

	struct index_pair {
		index_pair(int left, int rigth) : left(left), rigth(rigth) { }
		int left;
		int rigth;
	};

	void clear_all();

	void init_sample_counters();

	void update_sample_counters(int num_of_samples);

	void show_counters() const;

	front& current_front();

	const front& current_front() const;

	bool is_edge_fully_infeasible(int left_endpoint) const;

	bool is_edge_only_partly_feasible(int left_endpoint) const;

	bool is_edge_feasible(int left_endpoint) const;

	rmatrix& current_samples();

	const rmatrix& current_samples() const;

	rmatrix& input_for_next_front();

	const rmatrix& input_for_next_front() const;

	ivector& front_index_map();

	const ivector& get_index_map(int front_i) const;

	double get_delta() const;

	const std::vector<propagator::lin_ipol> sign_changes() const;

	const rvector solution_component(int front_i, const lin_ipol& image) const;

	const lin_ipol backward_step(int front_i, const lin_ipol& point) const;

	const index_pair find_enclosing_indices(int front_i, int index_in_input) const;

	double lambda(const rvector& x, const rvector& y, const rvector& c) const;

	void show_residuals() const;

	int remove_infeasible();

	int remove_strict_infeasiblity();

	int remove_strict_infeas_front(rmatrix& samples, ivector& indices);

	int remove_strict_infeas_back( rmatrix& samples, ivector& indices);

	void fix_partial_infeasibility();

	int remove_close_points();

	int insert_new_points();

	bool is_too_close(const rmatrix& samples, int k) const;

	double cos_angle(const rmatrix& samples, int k) const;

	void dump_sample_measures(const rmatrix& samples) const;

	int points_to_be_inserted(const rmatrix& samples, int k) const;

	int insert_with_lin_interpol(rmatrix& samples, int k);

	void compute_delta();

	void compute_scales();

	const rvector scaled_difference(const rvector& x, const rvector& y) const;

	double manifold_length() const;

	double distance_sqr(const rvector& x, const rvector& y) const;

	join_tree* fronts;

	int number_of_fronts;

	std::vector<rmatrix> in;

	std::vector<rmatrix> out;

	std::vector<rmatrix> internals;

	std::vector<rmatrix> solutions;

	imatrix index_map;

	struct {
		int begin;
		int end;
		int min;
		int max;
	}
	sample_size_counters;

	int current_front_index;

	double delta;

	rvector scales;

};

#endif
