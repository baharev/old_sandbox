//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#include <algorithm>
#include <cassert>
#include <iostream>
#include <iterator>
#include "rd_R1_eg.hpp"
#include "front.hpp"
#include "univariate_newton.hpp"

using namespace std;

namespace {

double lambda = 0.038;

const int N = 10;
const int C = 3;

const double H_vap = 40.6;
const double H = -80;

//const double V_reb = 628.630476;
const double beta = 0.958;

const double A[C][4] = {
		{  71.9,  5.72, 469, 35.9 },
		{ 221.2,  6.31, 647, 52.9 },
		{  77  ,  9.94, 645, 71.4 } };

const double W[N] = { 0.011, 1.447, 0.371, 0.447, 0.481, 0.551};

const double f[C][N] = {
		{  8.05, 0.2, 4.97, 4.69, 4.76, 4.89},
		{ 27.56 } };

const double nu[C] = { 1, 1, -1};

double distance_square(const rvector& x, const rvector& y) {

	double sum = 0.0;

	const int n = x.size();

	for (int i=0; i<n; ++i) {

		const double d = x.at(i) - y.at(i);

		sum += d*d;
	}

	return sum;
}

double summarize(const rvector& x, int first, int last) {

	double sum(0.0);

	for (int i=first; i<=last; ++i) {

		sum += x.at(i);
	}

	return sum;
}

const rvector normalize(const rvector& x, int first, int last) {

	const double sum = summarize(x, first, last);

	rvector result;

	for (int i=first; i<=last; ++i) {

		result.push_back(x.at(i)/sum);
	}

	return result;
}

void print(const rvector& v) {

	copy(v.begin(), v.end(), ostream_iterator<double>(cout, "\t"));
}

}

double eta_max() {

	const int C_REACT = 2;

	double sum[C_REACT] = { 0 };

	for (int i=0; i<C_REACT; ++i) {

		for (int j=0; j<N; ++j) {

			sum[i] += f[i][j];
		}

		sum[i] *= nu[i];
	}

	return *std::min_element(sum, sum+C_REACT);
}

class reboiler : public front {

	enum VARS { L1, L2, L3, V1, V2, V3, SIZE };

	virtual const rvector forward_propagate(const rvector& eta_initial) {

		assert(eta_initial.size()==1);

		const double eta_total = eta_initial.at(0);

		double b[C] = { 0 };

		for (int i=0; i<C; ++i) {

			b[i] = -nu[i]*eta_total; // This gives upper-bound on eta --> 27.56

			for (int j=0; j<N; ++j) {
				b[i] += f[i][j];
			}
		}

		const double lw =  1.0/(1.0-beta);
		const double vw = beta/(1.0-beta);

		const double result[SIZE] = {
			lw*b[0], lw*b[1], lw*b[2], vw*b[0], vw*b[1], vw*b[2]
		};

		return rvector(result, result+SIZE);
	}

//	virtual const rvector forward_propagate_my(const rvector& eta_initial) {
//
//		assert(eta_initial.size()==1);
//
//		const double eta_total = eta_initial.at(0);
//
//		double b[C] = { 0 };
//		double B    = 0.0;
//
//		for (int i=0; i<C; ++i) {
//
//			b[i] = -nu[i]*eta_total; // This gives upper-bound on eta --> 27.56
//
//			for (int j=0; j<N; ++j) {
//				b[i] += f[i][j];
//			}
//
//			B += b[i];
//		}
//
//		double x[C];
//
//		for (int i=0; i<C; ++i) {
//
//			x[i] = b[i]/B;
//		}
//
//		const double L = V_reb + B;
//
//		const double result[SIZE] = {
//			x[0]*L, x[1]*L, x[2]*L, x[0]*V_reb, x[1]*V_reb, x[2]*V_reb
//		};
//
//		return rvector(result, result+SIZE);
//	}

	virtual bool is_infeasible(const rvector& y) const {

		assert(y.size()==SIZE);

		for (size_t i=0; i<y.size(); ++i) {

			//assert(y.at(i) > -0.01); // HACK To allow infeasible eta
		}

		return false;
	}

	virtual const rvector project(const rvector& y) const {

		return normalize(y, L1, L3);
	}

	virtual const vec2 output_to_plot(const rvector& y) const {

		assert(y.size()==SIZE); // TODO Move size checking to the algorithm class

		const rvector x = normalize(y, L1, L3);

		return vec2(x.at(0), x.at(1));
	}

	virtual const vec2 input_to_plot(const rvector& x) const {

		assert(x.size()==1);

		return vec2(x.at(0), 0.0);
	}
};

// TODO Store the internal variables of the fronts

const double INFEAS_TOL = -0.1;

class reactive_stage : public front {

	enum VARS { L1, L2, L3, V1, V2, V3, SIZE };

	friend double newton_method<>(reactive_stage , double );

	const deriv_type operator()(const deriv_type& T) const {

		deriv_type K[C];

		deriv_type y[C];

		deriv_type sum_y(0.0);

		for (int i=0; i<C; ++i) {

			K[i] = A[i][0]*exp(A[i][1]*((T-A[i][2])/(T-A[i][3])));

			y[i] = K[i]*x[i];

			sum_y += y[i];
		}

		return sum_y - 1.0;
	}

	void y_from_T(double T) {

		double K[C];

		for (int i=0; i<C; ++i) {

			K[i] = A[i][0]*exp(A[i][1]*((T-A[i][2])/(T-A[i][3])));

			y[i] = K[i]*x[i];
		}
	}

	void eta_from_x_T(double T) {

		eta = lambda*W[j]*exp(37.0-(9547.7/T))*x[0]*x[1];
	}

	void out_vapors_from_heat_balance() {

		const double V = -(H/H_vap)*eta + V_p;

		for (int i=0; i<C; ++i) {

			v[i] = y[i]*V;
		}
	}

	void out_liquid_from_material_balance() {

		for (int i=0; i<C; ++i) {

			l_m[i] = v[i] + l[i] + nu[i]*eta - (f[i][j] + v_p[i]);
		}
	}

	void setup_variables(const rvector& vars) {

		const rvector x_in = normalize(vars, L1, L3);

		copy(x_in.begin(), x_in.end(), x);

		const rvector::const_iterator beg = vars.begin();

		copy(beg+L1, beg+V1, l);

		copy(beg+V1, beg+SIZE, v_p);

		V_p = 0;

		for (int i=0; i<C; ++i) {

			V_p += v_p[i];
		}

	}

	virtual const rvector forward_propagate(const rvector& vars) {

		setup_variables(vars);

		double T_estimate = 373.0;

		double T = newton_method((*this), T_estimate);

		y_from_T( T );

		eta_from_x_T( T );

		out_vapors_from_heat_balance();

		out_liquid_from_material_balance();

		rvector result(l_m, l_m+C);

		result.insert(result.end(), v, v+C);

		T_internal = T;

		return result;
	}

	virtual const rvector internal_vars() const { // TODO Would it be better to return T with the results?

		return rvector(1, T_internal);
	}

	virtual bool is_infeasible(const rvector& y) const {

		assert(y.size()==SIZE);

		for (size_t i=L1; i<=L3; ++i) {

			if (y.at(i) < INFEAS_TOL) {

				return true;
			}
		}

		return false;
	}

	virtual bool is_edge_only_partly_feasible(const rvector& a, const rvector& b) const {

		bool a_has_infeasibility = false;

		bool b_has_infeasibility = false;

		for (int i=L1; i<=L3; ++i) {

			double x = a.at(i);

			double y = b.at(i);

			if (x<INFEAS_TOL && y<INFEAS_TOL) {

				return false; // fully infeasible
			}

            if (x<INFEAS_TOL) {

				a_has_infeasibility = true;
			}

            if (y<INFEAS_TOL) {

				b_has_infeasibility = true;
			}
		}

		if (a_has_infeasibility && b_has_infeasibility) {

			return is_repairable(a, b);
		}

		return a_has_infeasibility || b_has_infeasibility;
	}

	bool is_repairable(const rvector& a, const rvector& b) const {

		double lambda = lambda_to_fix_right_infeas(a, b);

		return lambda >= 0 ? true : false;
	}

	// HACK A messy fix :(
	double lambda_to_fix_right_infeas(const rvector& left, const rvector& rigth) const {

		assert(is_infeasible(rigth));

		double lambda_max = 0.0;

		double lambda_min = 1.0;

		for (int i=L1; i<=L3; ++i) {

			double x = left.at(i);

			double y = rigth.at(i);

			assert(x >= INFEAS_TOL || y >= INFEAS_TOL);

			if (x >= INFEAS_TOL && y >= INFEAS_TOL) {

				continue;
			}

			double denom = x-y;

			if (denom==0) {

				continue;
			}

			double lam = (-y+INFEAS_TOL) / denom ;

			if (x>=INFEAS_TOL && lam > lambda_max) {

				lambda_max = lam;
			}

			if (x < INFEAS_TOL && lam < lambda_min) {

				lambda_min = lam;
			}
		}

		double lambda = -1;

		if (lambda_max <= lambda_min) {

			lambda = lambda_max;

			assert(0<=lambda && lambda<1.0001);
		}
		// else infeasible edge

		return lambda;
	}

	const rvector fix_infeasible_right_endpoint(const rvector& left, const rvector& rigth) const {

		const double lambda = lambda_to_fix_right_infeas(left, rigth);

		assert(0<=lambda && lambda<1.0001);

		rvector y_feas(SIZE);

		for (int i=0; i<SIZE; ++i) {

			const double x = left.at(i);

			const double y = rigth.at(i);

			const double y_new = lambda*x + (1-lambda)*y;

			//double lam = (-y+INFEAS_TOL) / (x-y);

			assert(i>L3 || y_new+0.001 > INFEAS_TOL);

			y_feas.at(i) = y_new;
		}

		return y_feas;
	}

	void fix_both_infeas_endpoints(rvector& a, rvector& b) const {

		cout << "fixing infeasible edge" << endl;
		cout << "a: "; print(a); cout << endl;
		cout << "b: "; print(b); cout << endl;

		rvector feas_a(fix_infeasible_right_endpoint(b, a));

		rvector feas_b(fix_infeasible_right_endpoint(a, b));

		a = feas_a;

		b = feas_b;

		cout << "after fixing it is:" << endl;
		cout << "a: "; print(a); cout << endl;
		cout << "b: "; print(b); cout << endl;
	}


	void fix_partial_infeasibility(rvector& left, rvector& rigth) const {

		if (is_infeasible(left) && is_infeasible(rigth)) {

			fix_both_infeas_endpoints(left, rigth);
		}
		else {

			rigth = fix_infeasible_right_endpoint(left, rigth);
		}

		for (int i=L1; i<=L3; ++i) {

			assert( left.at(i)+0.001 > INFEAS_TOL);

			assert(rigth.at(i)+0.001 > INFEAS_TOL);
		}
	}

	virtual const rvector project(const rvector& y) const {

		return normalize(y, L1, L3);
	}

	virtual const vec2 output_to_plot(const rvector& y) const {

		const rvector x = normalize(y, L1, L3);

		return vec2(x.at(0), x.at(1));
	}

	double l[C];
	double x[C];
	double v[C];
	double y[C];
	double eta;
	double V_p;
	double v_p[C];
	double l_m[C];

	double T_internal;

	int j;

public:

	front& stage(int index) { // TODO Dirty quick-fix

		index = N-1 - index;

		assert(0<=index && index<N);

		j = index;

		return *this;
	}
};

class total_condenser : public front {

	enum INPUT_VARS { L1, L2, L3, V1, V2, V3, SIZE };

	virtual const rvector forward_propagate(const rvector& input) {

		assert(input.size()==SIZE);

		const double V = summarize(input, V1, V3);

		const double L = summarize(input, L1, L3);

		return rvector(1, (V-L)/V);
	}

	virtual bool is_infeasible(const rvector& y) const { assert(false); return false; }

	virtual const rvector project(const rvector& y) const { assert(false); return rvector(); }

	virtual const vec2 output_to_plot(const rvector& y) const {

		return vec2(y.at(0), 0.0); // TODO What should we do here?
	}
};

void set_lambda(double lam) {

	lambda = lam;
}

double get_lambda() {

	return lambda;
}

reactive_distillation::reactive_distillation()
:  n_stages(10),
   n_fronts(n_stages+2),
   m_reactive_stage(new reactive_stage),
   m_reboiler(new reboiler),
   m_total_condenser(new total_condenser)
{

}

int reactive_distillation::size() const {

	return n_fronts;
}

front& reactive_distillation::get_front(int i) {

	if (i == 0) {

		return *m_reboiler;
	}
	else if (1<=i && i<=n_stages) {

		return m_reactive_stage->stage(i-1);
	}
	else if (i==n_fronts-1) {

		return *m_total_condenser;
	}
	else {
		assert(false);
		return *(front*)0; // TODO eliminate C style cast
	}
}

reactive_distillation::~reactive_distillation() {

}
