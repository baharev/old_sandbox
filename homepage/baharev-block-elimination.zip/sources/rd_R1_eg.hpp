//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#ifndef RD_R1_EG_HPP_
#define RD_R1_EG_HPP_

#include <memory>
#include "join_tree.hpp"

class reactive_stage;
class reboiler;
class total_condenser;

class reactive_distillation : public join_tree {

public:

	reactive_distillation();

	~reactive_distillation();

private:

	virtual int size() const;

	virtual front& get_front(int i);

	const int n_stages;

	const int n_fronts;

	const std::auto_ptr<reactive_stage>   m_reactive_stage;
	const std::auto_ptr<reboiler>         m_reboiler;
	const std::auto_ptr<total_condenser>  m_total_condenser;

};

void set_lambda(double lam);

double get_lambda();

double eta_max();

#endif

