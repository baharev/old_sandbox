//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#include <cassert>
#include "reactor_column.hpp"
#include "front.hpp"
#include "deriv_type.hpp"
#include "univariate_newton.hpp"

using namespace std;

namespace {

const double Qr = 1432449.0;
const double R  = 172.51;
const double z0 = 0.0;
const double TF0 = 140.0;
const double VR = 1200.0;
const double N = 18;
const double P  = 50.0;

const double L = R;

const double k10  = 0.1538e4;
const double k20  = 0.848e10;
const double E1 = 10000;
const double E2 = 30000;

const double RG = 1.98588;
const double Hvap = 250.0;
const double Cp = 0.75;
const double lambda = -20000.0;
const double M = 50.0;

const double b1A = -2818.0;
const double b2A =  8.168;
const double b1B = -2818.0;
const double b2B =  8.861;
const double alpha = 2.0;

const double KMT = 10513.0;

const double V_SCALE = 500.0;

}

double distance_sqr(double x, double y) {

	const double d = x - y;

	return d*d;
}

class reactor : public front {

	double TR;
	double PA;
	double PB;

	deriv_type PR;
	deriv_type yB;
	deriv_type V;
	deriv_type F0;
	deriv_type rxt;
	deriv_type x1;
	deriv_type T1;

	friend double newton_method<>(reactor , double );

	double rector_concentration() {

		PA = exp(b1A/(TR+460)+b2A);

		PB = exp(b1B/(TR+460)+b2B);

		double z_estimate(0.6);

		return newton_method(*this, z_estimate);
	}

	const deriv_type operator()(const deriv_type& z) { // Heat balance residual

		PR = PA*(1-z) + PB*z;

		yB = (PB/PR)*z;

		V = KMT/M*(PR-P);

		F0 = V - L;

		rxt = k10*exp(-E1/(RG*(TR+460)))*(1-z)-k20*exp(-E2/(RG*(TR+460)))*z;

		x1 = (V*yB - F0*z0 - VR*(rxt))/L;                 // TODO Can become negative
                                                          //
		T1 = b1B/(log(alpha*P/(1+(alpha-1)*x1))-b2B)-460; // log fails if x1<0

		deriv_type residual = F0*TF0 - V*TR + L*T1 - V*Hvap/Cp - (lambda*VR*rxt-Qr)/(M*Cp);

		return residual;
	}

	const rvector forward_propagate(const rvector& T_reactor) {
		// TODO Move size checking into the algorithm
        // and force fronts to implement in/output size?
		assert(T_reactor.size()==1);

		TR = T_reactor.at(0);

		double z = rector_concentration();
		// TODO Eliminate this workaround that gets the remaining variables
		(*this)(deriv_type(z));

		const double res[] = { x1.f_value(), yB.f_value(), V.f_value() };

		return rvector(res, res+SIZE);
	}

	enum VAR_NAME { X, Y, V0, SIZE };

	virtual const rvector project(const rvector& y) const {

		assert(y.size()==SIZE);

		return rvector(1, y.at(X));
	}

	bool is_infeasible(const rvector& output_vector) const {

		bool infeasible = false;

		const double x = output_vector.at(X);
		const double y = output_vector.at(Y);
		const double V = output_vector.at(V0);

		if ( (x < -0.01 || x > 1.01) ||
			 (y < -0.01 || y > 1.01) ||
			 (V  < L - 0.01) )
		{
			infeasible = true;
		}

		return infeasible;
	}

	virtual const vec2 output_to_plot(const rvector& y) const {

		//return vec2(y.at(X),y.at(Y));
		return vec2(y.at(X),y.at(V0)/V_SCALE);
		//return vec2(y.at(Y),y.at(V0)/V_SCALE);
	}

	virtual const vec2 input_to_plot(const rvector& y) const {

		return vec2(y.at(0),0.0);
	}
};

class stage : public front {

	enum VAR_NAME { X, Y, V, SIZE };

	const rvector forward_propagate(const rvector& x_y_V) {

		assert(x_y_V.size()==SIZE);

		const double x_in = x_y_V.at(X);
		const double y_in = x_y_V.at(Y);
		const double V_in = x_y_V.at(V);

		const double y = (alpha*x_in)/(1+(alpha-1)*x_in);
		const double x = x_in + (V_in/L)*(y - y_in);

		const double res[] = { x, y, V_in };

		return rvector(res, res+SIZE);
	}

	virtual const rvector project(const rvector& y) const {

		assert(y.size()==SIZE);

		return rvector(1, y.at(X));
	}

	bool is_infeasible(const rvector& output_vector) const {

		bool infeasible = false;

		const double x = output_vector.at(X);
		const double y = output_vector.at(Y);
		const double Vap = output_vector.at(V);

		if ( (x < -0.01 || x > 1.01) ||
			 (y < -0.01 || y > 1.01) ||
			 (Vap  < L - 0.01) )
		{
			infeasible = true;
		}

		return infeasible;
	}

	virtual const vec2 output_to_plot(const rvector& y) const {

		//return vec2(y.at(X),y.at(Y));
		return vec2(y.at(X),y.at(V)/V_SCALE);
		//return vec2(y.at(Y),y.at(V)/V_SCALE);
	}
};

class condenser : public front {

	enum VAR_NAME { X, Y, V, SIZE };

	const rvector forward_propagate(const rvector& x_y_V) {

		const double res = residual(x_y_V);

		return rvector(1, res); // TODO Overkill to make vector from double...
	}

	virtual bool is_infeasible(const rvector& ) const { assert(false); return true; }

	virtual const rvector project(const rvector& y) const { assert(false); return rvector(); }

	double residual(const rvector& x_y_V) {

		assert(x_y_V.size()==SIZE);

		const double x_in = x_y_V.at(X);
		const double y_in = x_y_V.at(Y);

		return y_in - x_in;
	}

	virtual const vec2 input_to_plot(const rvector& y) const {

		//return vec2(y.at(X),y.at(Y));
		return vec2(y.at(X),y.at(V)/V_SCALE);
		//return vec2(y.at(Y),y.at(V)/V_SCALE);
	}

	virtual const vec2 output_to_plot(const rvector& y) const {
		return vec2(y.at(0),0);
	}
};

reactor_column::reactor_column()
: n_stages(18),
  n_fronts(n_stages+2),
  m_reactor(new reactor),
  m_stage(new stage),
  m_condenser(new condenser)
{

}

front& reactor_column::get_front(int front_i) {

	if (front_i == 0) {

		return *m_reactor;
	}
	else if (1<=front_i && front_i<=n_stages) {

		return *m_stage;
	}
	else if (front_i==n_fronts-1) {

		return *m_condenser;
	}
	else {
		assert(false);
		return *(front*)0; // TODO Eliminate C style cast
	}
}

int reactor_column::size() const {

	return n_fronts;
}

reactor_column::~reactor_column() {

}
