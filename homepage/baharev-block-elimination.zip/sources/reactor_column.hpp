//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#ifndef REACTOR_COLUMN_HPP_
#define REACTOR_COLUMN_HPP_

#include <memory>
#include "join_tree.hpp"

class reactor;
class stage;
class condenser;

class reactor_column : public join_tree {

public:

	reactor_column();

	~reactor_column();

private:

	virtual int size() const;

	virtual front& get_front(int i);

	const int n_stages;

	const int n_fronts;

	const std::auto_ptr<reactor>   m_reactor;
	const std::auto_ptr<stage>     m_stage;
	const std::auto_ptr<condenser> m_condenser;

};

#endif
