//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#include <iostream>
#include <sstream>
#include "search_coordinator.hpp"
#include "propagator.hpp"

using namespace std;

int search_coordinator::unique_id = 0;

search_coordinator::search_coordinator(propagator prop)
:  props(vector<propagator>(1,prop))
{

}

const std::vector<rmatrix>& search_coordinator::get_solutions() const {

	return solutions;
}

void search_coordinator::run() {

	solutions.clear();

	for (int front_i=0; !props.empty() && props.at(0).has_next_front(); ++front_i) {

		setfront();

		process_samples();

		copy_output_to_input_of_next();

		handle_discontinuities();

		prepare_input_for_next();
	}

	int all_solutions = dump_results();

	cout << "Solutions found: " << all_solutions << endl;
}

void search_coordinator::setfront() {

	for (size_t i_prop = 0; i_prop < props.size(); ++i_prop) {

		propagator& p = props.at(i_prop);

		p.set_next_front();

		cout << "manifold part " << i_prop << endl;
	}
}

void search_coordinator::process_samples() {

	for (size_t i_prop = 0; i_prop < props.size(); ++i_prop) {

		propagator& p = props.at(i_prop);

		p.process_each_sample_at_front();
	}
}

void search_coordinator::copy_output_to_input_of_next() {

	for (size_t i_prop = 0; i_prop < props.size(); ++i_prop) {

		propagator& p = props.at(i_prop);

		p.copy_output_to_input_of_next();
	}
}

void search_coordinator::create_new_propagators(propagator& p, int discon) {

	const propagator old(p);

	p.keep_only_part(0);

	for (int k=1; k<=discon; ++k) {

		propagator new_prop(old);

		new_prop.keep_only_part(k);

		props.push_back(new_prop);
	}
}

void search_coordinator::handle_discontinuities() {

	size_t n_props = props.size();

	for (size_t i_prop = 0; i_prop < n_props; ++i_prop) {

		propagator& p = props.at(i_prop);

		int discon = p.discontinuities();

		if (discon > 0) {

			cout << "*** branching ***" << endl;

			create_new_propagators(p, discon);
		}
		else if (discon == -1) {

			cout << "### part became fully infeasible ###" << endl;
			dump_infeasible(p);

			props.erase(props.begin()+i_prop);
			--i_prop;
			--n_props;
		}
	}
}

void search_coordinator::dump_infeasible(const propagator& p) const {

	const string filename = unique_file_name();

	p.dump_dataset_to_plot(filename.c_str());

	cout << "dumped to " << filename << endl;
}

void search_coordinator::prepare_input_for_next() {

	for (size_t i_prop = 0; i_prop < props.size(); ++i_prop) {

		propagator& p = props.at(i_prop);

		if (!p.is_last_front()) cout << "\nmanifold part " << i_prop << endl;

		p.prepapare_input_of_next();
	}
}

const string search_coordinator::unique_file_name() const {

	ostringstream os;

	os << "mm_" << unique_id++ << ".asy";

	return os.str();
}

int search_coordinator::dump_results() {

	int n_solutions = 0;

	for (size_t i_prop = 0; i_prop < props.size(); ++i_prop) {

		propagator& p = props.at(i_prop);

		n_solutions += p.dump_results();

		cout << "manifold part " << i_prop << endl;

		const vector<rmatrix>& sols = p.backward_sweep_new();

		solutions.insert(solutions.end(), sols.begin(), sols.end());

		const string file_name = unique_file_name();

		p.dump_dataset_to_plot(file_name.c_str());

		cout << "data in " << file_name << endl;
	}

	return n_solutions;
}
