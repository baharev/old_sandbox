//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#ifndef SEARCH_COORDINATOR_HPP_
#define SEARCH_COORDINATOR_HPP_

#include <string>
#include "array_typedefs.hpp"

class propagator;

class search_coordinator {

public:

	search_coordinator(propagator prop);

	void run();

	const std::vector<rmatrix>& get_solutions() const;

private:

	void setfront();

	void process_samples();

	void copy_output_to_input_of_next();

	void create_new_propagators(propagator& p, int discon);

	void handle_discontinuities();

	void prepare_input_for_next();

	const std::string unique_file_name() const;

	void dump_infeasible(const propagator& p) const;

	int dump_results();

	std::vector<propagator> props;

	std::vector<rmatrix> solutions;

	static int unique_id;
};

#endif
