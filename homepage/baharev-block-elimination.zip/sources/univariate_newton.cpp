//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#include <cmath>
#include "univariate_newton.hpp"

const double MAX_STEP_LENGTH = 10;

double newton_step(const double x, const double fx, const double dfx) {

	double step = fx/dfx;

	if (std::abs(step) > MAX_STEP_LENGTH) {

		step = ( step>=0 ? 1 : -1 )*MAX_STEP_LENGTH;
	}

	const double x_new = x - step;

	return x_new;
}
