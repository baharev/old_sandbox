//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#ifndef UNIVARIATE_NEWTON_HPP_
#define UNIVARIATE_NEWTON_HPP_

#include <stdexcept>
#include "deriv_type.hpp"

const int MAX_STEPS = 20;

const double TOL = 1.0e-12;

double newton_step(const double x, const double fx, const double dfx);

template <typename univariate_function>
double newton_method(univariate_function f, double x_estimate) {

	double x = x_estimate;

	for (int i=0; i<MAX_STEPS; ++i) {

		const deriv_type fx = f( deriv_type(x, 1.0) );

		const double x_old = x;

		x = newton_step(x_old, fx.f_value(), fx.derivative());

		const bool converged = std::abs(x_old-x)<TOL*x_old;

		if (converged) {

			return x;
		}
	}

	throw std::runtime_error("iteration limit reached in Newton method");

	return 0;
}

#endif
