//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#include <fstream>
#include "vector_graphics.hpp"

using namespace std;

vector_graphics::vector_graphics(const char* file_name)
:
		outfile(new ofstream(file_name)),
		out(*outfile)
{
	out.exceptions(ios_base::badbit | ios_base::failbit);
}

void vector_graphics::write(const char* array_name, const matrix_vec2& dataset) {

	out << "pair[][] " << array_name << " = {\n";

	const int n = dataset.size();

	for (int i=0; i<n; ++i) {

		out << "\n{";

		write(dataset.at(i));

		out << (i==n-1? "}\n" : "},");
	}

	out << "};\n\n";

	out.flush();
}

void vector_graphics::write(const vector_vec2& array) {

	const int n = array.size();

	for (int i=0; i<n; ++i) {

		const vec2& v = array.at(i);

		out << "\n(\t" << v.x << ",\t" << v.y << ")";

		out << (i==n-1?'\n':',');
	}
}

void vector_graphics::write_line(const char* line) {

	out << line << '\n';
}

vector_graphics::~vector_graphics() {

}
