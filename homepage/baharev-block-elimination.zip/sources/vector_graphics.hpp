//  Copyright (c) 2012, University of Vienna
//  All rights reserved.
//  This code is published under the New BSD License.
//  Author: Ali Baharev
#ifndef VECTOR_GRAPHICS_HPP_
#define VECTOR_GRAPHICS_HPP_

#include <iosfwd>
#include <memory>
#include "array_typedefs.hpp"

class vector_graphics {

public:

	vector_graphics(const char* file_name);

	void write_line(const char* line);

	void write(const char* array_name, const matrix_vec2& dataset);

	~vector_graphics();

private:

	void write(const vector_vec2& array);

	const std::auto_ptr<std::ofstream> outfile;

	std::ofstream& out;
};

#endif
