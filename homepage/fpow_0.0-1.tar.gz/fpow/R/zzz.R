.First.lib <- function(lib, pkg) library.dynam("fpow", pkg, lib)
