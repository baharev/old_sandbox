.onLoad <- function(lib, pkg) library.dynam("fpow", pkg, lib)
